import matplotlib.pyplot as plt
from datetime import datetime
import numpy as np
def bead_Sort(a):
    size = len(a)
    maximum_No = max(a)
    # Initializing 2d array of beads with 0 of rows*coloums (max)*(size)
    beads = [[0]*maximum_No for _ in range(size) ]
    #print(beads)(
    for i in range(size):
        for j in range(a[i]):
            beads[i][j] = 1
    #print(beads)

    ## Algorithm works as following 
    #  Lets see it as follow  1, 1, 0, 0, 0, 0
    #                         1, 1, 1, 1, 1, 1
    #                         1, 1, 1, 1, 0, 0
    #                         1, 1, 1, 0, 0, 0
    # First it will iterate through the coloum 1 of the matrix by writing 1 on it and adding the sum  
    # Then it will iterate bottom to up to again converting the 0 into 1 upto the ' int size' 

    #Step 1
    for j in range(maximum_No):
        sum = 0
        for k in range(size):
            sum += beads[k][j]
            beads[k][j] = 0
    #Step 2        
        for i in range(size-1,size-sum-1,-1):
          beads[i][j] = 1
    #Step 3      
        for i in range(size):
          no_of_Ons_in_row = beads[i].count(1)
          a[i] = no_of_Ons_in_row           
    return a       
# def bead_sort(a):
#     minimum, maximum = min(a), max(a)
#     n = len(a)

    # Initialize a temporary array filled with minimum
    # temp = [minimum] * n
    # for i in range(maximum-1, minimum-1, -1):
    #     k = 0
    #     for j in range(n):
    #         if a[j] > i:
    #             temp[k] += 1
    #             k += 1

    # Copy temp array back into original array
    # replacing the array into sorted order
    # temp array is reverse sorted, so copy backwards for ascending order
    # for i in range(n):
    #     a[i] = temp[n-i-1]

inp = [1000,5000,10000,20000,30000,40000,50000,75000,100000,200000]
interval_arr = []
for i in inp:
    randi_arr = np.random.randint(0, i, i)
    now = datetime.now()
    bead_sort(randi_arr)
    later = datetime.now()
    difference = later-now
    difference = difference.total_seconds() * 1000
    interval_arr.append(difference)
    
plt.plot(inp, interval_arr, color='green', linestyle='dashed', linewidth = 2,
         marker='o', markerfacecolor='black', markersize=5)
plt.xlabel("Input-Size")
plt.ylabel("Time(Sec)")
plt.title("Counting Sort:(Design and Analysis of Algorithms(DAA))")

plt.show()